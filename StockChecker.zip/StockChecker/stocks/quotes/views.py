from django.contrib.auth import authenticate, login
from django.shortcuts import render, redirect
from .models import Stock
from .forms import StockForm,CreateUserForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib import messages



def registerPage(request):
    form = CreateUserForm()

    if request.method == 'POST':
        form = CreateUserForm(request.POST)
        if form.is_valid():
            form.save()
            user = form.cleaned_data.get('username')
            messages.success(request,'Account was created for '+ user)

            return redirect('login')
    else:
        form = CreateUserForm()
    return render(request, 'register.html', {'form': form})





def loginPage(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')



        user = authenticate(request, username =username , password = password)

        if user is not None:
            login(request,user)
            return redirect('add_stock')
    context = {}
    return render(request,'login.html',context)



def home(request):
    import requests
    import json

    if request.method == "POST":
        ticker = request.POST['ticker']
        api_request = requests.get(
            "https://cloud.iexapis.com/stable/stock/"+ticker+ "/quote?token=pk_eeef872957e94510b77b99ae849ddccc")
        try:
            api = json.loads(api_request.content)
        except Exception as e:
            api = "Error"
        return render(request, 'home.html', {'api': api})
    else:


        return render(request,'home.html',{'ticker' : "Enter a ticker symbol"})





def about(request):
    return render(request , 'about.html' , {})

def add_stock(request):
    import requests
    import json
    if request.method == "POST":
        form = StockForm(request.POST or None)

        if form.is_valid():
            form.save()
            messages.success(request,("Stock has been added !!"))
            return  redirect('add_stock')

    else:
        ticker = Stock.objects.all()
        output = []

        for ticker_item in ticker:
            api_request = requests.get("https://cloud.iexapis.com/stable/stock/" + str(ticker_item) + "/quote?token=pk_eeef872957e94510b77b99ae849ddccc")
            try:
                api = json.loads(api_request.content)
                output.append(api)
            except Exception as e:
                api = "Error"


        return render(request, 'add_stock.html', {'ticker': ticker,'output' : output})

def delete(request, stock_id):
    item = Stock.objects.get(pk=stock_id)
    item.delete()
    messages.success(request, ("Stock is removed successfully"))
    return redirect(delete_stock)

def delete_stock(request):
    ticker = Stock.objects.all()
    return render(request , 'delete_stock.html' , {'ticker':ticker})
